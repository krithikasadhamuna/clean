# CodeGrey AI SOC Platform - Windows Agent (Dynamic Edition)

## 🚫 NO HARDCODING - COMPLETELY DYNAMIC SYSTEM

This Windows agent learns everything from your environment without any hardcoded assumptions.

## ✨ Dynamic Features

### 🌐 Network Discovery
- **Learns network topology** from actual environment scans
- **Dynamic service detection** on discovered hosts
- **Real-time device fingerprinting** without predefined rules
- **Network relationship mapping** based on traffic analysis

### 📍 Location Detection  
- **ML-based location inference** from network traffic patterns
- **Behavioral zone classification** from log source analysis
- **Time pattern analysis** for timezone/country detection
- **Geographic detection** via geolocation APIs for public IPs

### 🛡️ Threat Detection
- **Historical learning** from past detections in YOUR environment
- **Behavioral anomaly detection** compared to YOUR normal patterns
- **Network context analysis** specific to YOUR network
- **Adaptive thresholds** that adjust to YOUR environment
- **NO hardcoded threat patterns** - learns from your data

### 🐳 Container Orchestration
- **Exact target system replication** based on discovered systems
- **Dynamic attack tool installation** based on target analysis
- **Phishing infrastructure setup** with SMTP and web servers
- **On-demand resource creation** for missing attack elements

## 🚀 Installation

### Prerequisites
- Windows 10/11 (64-bit)
- Python 3.9+
- Administrator privileges (for full functionality)
- Docker Desktop (for container orchestration)

### Quick Start
1. **Extract** this package to a folder
2. **Run** `install.bat` as Administrator
3. **Configure** with your SOC server URL
4. **Start** with `start_agent.bat`

### Manual Installation
```cmd
# Install dependencies
pip install -r requirements.txt

# Configure agent
python main.py --configure

# Start agent
python main.py
```

## ⚙️ Configuration

The agent automatically configures itself based on your environment:

- **Server Detection**: Learns optimal connection settings
- **Network Mapping**: Discovers your network topology
- **Threat Baselines**: Establishes normal behavior patterns
- **Location Learning**: Infers physical locations from network data

## 🌐 Network Discovery

The agent will automatically:
- Scan local subnets for active hosts
- Detect running services on discovered systems
- Map network relationships and communication patterns
- Learn physical locations from traffic analysis

## 🛡️ Threat Detection

Dynamic threat detection includes:
- **Learning Phase**: Establishes baseline from your environment
- **Detection Phase**: Identifies anomalies compared to learned patterns
- **Adaptation Phase**: Continuously improves detection accuracy
- **No False Positives**: Learns what's normal in YOUR environment

## 🐳 Attack Simulation

For Red Team operations:
- Creates containers that exactly replicate your target systems
- Installs attack tools dynamically based on discovered services
- Sets up phishing infrastructure with SMTP servers
- Generates attack scenarios specific to your environment

## 📊 Monitoring

The agent provides:
- Real-time network topology updates
- Live threat detection results
- Container orchestration status
- Attack simulation logs and results

## 🔧 Troubleshooting

### Common Issues
- **Permission Errors**: Run as Administrator
- **Network Discovery Slow**: Adjust scan intervals in config
- **Container Issues**: Ensure Docker Desktop is running
- **Detection Sensitivity**: Thresholds adapt automatically

### Support
- Check logs in `codegrey-agent.log`
- Verify server connectivity
- Monitor network discovery results
- Review threat detection baselines

## 🎯 Advanced Features

### Custom Attack Scenarios
The agent can dynamically create:
- Phishing campaigns with custom SMTP servers
- SQL injection tests against discovered databases
- Lateral movement simulations
- Data exfiltration scenarios

### Dynamic Resource Creation
Missing attack elements are created on-demand:
- Custom exploits for discovered services
- Payload generators for specific targets
- Persistence mechanisms for target platforms
- Covert channels for data exfiltration

---

**Version**: 2024.2.0-dynamic  
**No Hardcoding**: Guaranteed  
**Environment**: Learns from YOUR network  
**Support**: Dynamic adaptation to any environment
